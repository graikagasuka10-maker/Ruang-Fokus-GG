package id.ruangfokus.app

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.provider.CalendarContract
import java.time.Instant
import java.time.ZoneId

data class DeviceCalendar(val id: Long, val name: String, val accountName: String, val accountType: String)
data class CalendarEvent(
    val id: Long,
    val calendarId: Long,
    val title: String,
    val description: String?,
    val startMillis: Long,
    val endMillis: Long,
    val allDay: Boolean,
    val updatedMillis: Long
)

/**
 * Uses Android Calendar Provider. It accesses only calendars exposed by the device's
 * calendar provider and permitted by the user. Xiaomi/Redmi calendar availability varies
 * by ROM, account configuration, and sync settings.
 */
class CalendarRepository(private val context: Context) {
    fun listCalendars(): List<DeviceCalendar> {
        val result = mutableListOf<DeviceCalendar>()
        val projection = arrayOf(
            CalendarContract.Calendars._ID,
            CalendarContract.Calendars.CALENDAR_DISPLAY_NAME,
            CalendarContract.Calendars.ACCOUNT_NAME,
            CalendarContract.Calendars.ACCOUNT_TYPE
        )
        context.contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI, projection, null, null,
            CalendarContract.Calendars.CALENDAR_DISPLAY_NAME + " ASC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(CalendarContract.Calendars._ID)
            val nameCol = c.getColumnIndexOrThrow(CalendarContract.Calendars.CALENDAR_DISPLAY_NAME)
            val accountCol = c.getColumnIndexOrThrow(CalendarContract.Calendars.ACCOUNT_NAME)
            val typeCol = c.getColumnIndexOrThrow(CalendarContract.Calendars.ACCOUNT_TYPE)
            while (c.moveToNext()) {
                result += DeviceCalendar(
                    c.getLong(idCol), c.getString(nameCol) ?: "Kalender",
                    c.getString(accountCol) ?: "", c.getString(typeCol) ?: ""
                )
            }
        }
        return result
    }

    fun readEvents(calendarId: Long, fromMillis: Long, toMillis: Long): List<CalendarEvent> {
        val result = mutableListOf<CalendarEvent>()
        val uri = CalendarContract.Instances.CONTENT_URI.buildUpon().apply {
            ContentUris.appendId(this, fromMillis)
            ContentUris.appendId(this, toMillis)
        }.build()
        val projection = arrayOf(
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.CALENDAR_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.DESCRIPTION,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.ALL_DAY,
            CalendarContract.Instances.EVENT_ID
        )
        val selection = "${CalendarContract.Instances.CALENDAR_ID}=?"
        context.contentResolver.query(uri, projection, selection, arrayOf(calendarId.toString()),
            CalendarContract.Instances.BEGIN + " ASC")?.use { c ->
            val eventId = c.getColumnIndexOrThrow(CalendarContract.Instances.EVENT_ID)
            val calId = c.getColumnIndexOrThrow(CalendarContract.Instances.CALENDAR_ID)
            val title = c.getColumnIndexOrThrow(CalendarContract.Instances.TITLE)
            val desc = c.getColumnIndexOrThrow(CalendarContract.Instances.DESCRIPTION)
            val begin = c.getColumnIndexOrThrow(CalendarContract.Instances.BEGIN)
            val end = c.getColumnIndexOrThrow(CalendarContract.Instances.END)
            val allDay = c.getColumnIndexOrThrow(CalendarContract.Instances.ALL_DAY)
            while (c.moveToNext()) {
                result += CalendarEvent(
                    c.getLong(eventId), c.getLong(calId), c.getString(title) ?: "(Tanpa judul)",
                    c.getString(desc), c.getLong(begin), c.getLong(end),
                    c.getInt(allDay) == 1, 0L
                )
            }
        }
        return result
    }

    fun insertEvent(
        calendarId: Long, title: String, description: String,
        startMillis: Long, endMillis: Long, reminderMinutes: Int = 10
    ): Long {
        require(endMillis > startMillis) { "Waktu selesai harus setelah waktu mulai." }
        val values = ContentValues().apply {
            put(CalendarContract.Events.DTSTART, startMillis)
            put(CalendarContract.Events.DTEND, endMillis)
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DESCRIPTION, description)
            put(CalendarContract.Events.CALENDAR_ID, calendarId)
            put(CalendarContract.Events.EVENT_TIMEZONE, ZoneId.systemDefault().id)
            put(CalendarContract.Events.HAS_ALARM, 1)
        }
        val uri = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
            ?: error("Kalender menolak pembuatan acara.")
        val eventId = ContentUris.parseId(uri)
        val reminder = ContentValues().apply {
            put(CalendarContract.Reminders.EVENT_ID, eventId)
            put(CalendarContract.Reminders.MINUTES, reminderMinutes)
            put(CalendarContract.Reminders.METHOD, CalendarContract.Reminders.METHOD_ALERT)
        }
        context.contentResolver.insert(CalendarContract.Reminders.CONTENT_URI, reminder)
        return eventId
    }

    fun updateEvent(eventId: Long, title: String, description: String, startMillis: Long, endMillis: Long) {
        require(endMillis > startMillis) { "Waktu selesai harus setelah waktu mulai." }
        val uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId)
        val values = ContentValues().apply {
            put(CalendarContract.Events.TITLE, title)
            put(CalendarContract.Events.DESCRIPTION, description)
            put(CalendarContract.Events.DTSTART, startMillis)
            put(CalendarContract.Events.DTEND, endMillis)
            put(CalendarContract.Events.EVENT_TIMEZONE, ZoneId.systemDefault().id)
        }
        val count = context.contentResolver.update(uri, values, null, null)
        check(count > 0) { "Acara tidak ditemukan atau tidak dapat diubah." }
    }

    fun deleteEvent(eventId: Long) {
        val uri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, eventId)
        val count = context.contentResolver.delete(uri, null, null)
        check(count > 0) { "Acara tidak ditemukan atau tidak dapat dihapus." }
    }
}
