package id.ruangfokus.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import java.time.LocalDate
import java.time.ZoneId

class MainActivity : Activity() {
    private val requestCalendarPermissions = 200
    private val requestNotificationPermission = 201
    private lateinit var repo: CalendarRepository
    private lateinit var root: LinearLayout
    private var calendars: List<DeviceCalendar> = emptyList()
    private var selectedCalendar: DeviceCalendar? = null
    private var statusView: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        repo = CalendarRepository(this)
        renderHome()
        requestNotificationsIfNeeded()
    }

    private fun baseLayout(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 24)
        }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        root.addView(TextView(this).apply {
            text = title
            textSize = 26f
            setPadding(0, 0, 0, 8)
        })
    }

    private fun addText(text: String, size: Float = 15f) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = size
            setPadding(0, 8, 0, 8)
        })
    }

    private fun addButton(text: String, action: () -> Unit) {
        root.addView(Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { action() }
        })
    }

    private fun renderHome() {
        baseLayout("🌿 Ruang Fokus")
        addText("Planner belajar • kalender • pengingat", 16f)
        addText("Prototipe Android. Pilih kalender, lalu impor atau ekspor acara.")
        addButton("📅 Hubungkan / pilih kalender") { checkCalendarPermissionAndOpen() }
        addButton("⬇ Impor acara 30 hari ke depan") { importEvents() }
        addButton("⬆ Tambahkan jadwal belajar ke kalender") { showCreateStudyEvent() }
        addButton("✨ Saran AI belajar") { showStudyAdvice() }
        addButton("🔄 Sinkronkan sekarang") { syncNow() }
        statusView = TextView(this).apply {
            text = "Status: belum ada kalender dipilih."
            textSize = 14f
            setPadding(0, 16, 0, 8)
        }
        root.addView(statusView)
        addText("Penting: prototipe ini menyediakan operasi kalender dasar. Sinkronisasi dua arah otomatis penuh dan konflik multi-perangkat belum selesai di versi awal.")
    }

    private fun hasCalendarPermissions(): Boolean {
        return checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED
    }

    private fun checkCalendarPermissionAndOpen() {
        if (!hasCalendarPermissions()) {
            requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), requestCalendarPermissions)
        } else chooseCalendar()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == requestCalendarPermissions) {
            if (hasCalendarPermissions()) chooseCalendar()
            else toast("Izin kalender diperlukan untuk membaca dan menulis acara.")
        }
    }

    private fun requestNotificationsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), requestNotificationPermission)
        }
    }

    private fun chooseCalendar() {
        try {
            calendars = repo.listCalendars()
            if (calendars.isEmpty()) {
                AlertDialog.Builder(this).setTitle("Tidak ada kalender tersedia")
                    .setMessage("Android tidak menampilkan kalender yang bisa diakses. Pastikan aplikasi kalender/akun sudah disiapkan dan kalender tersinkron.")
                    .setPositiveButton("OK", null).show()
                return
            }
            val labels = calendars.map { "${it.name} • ${it.accountName.ifBlank { it.accountType }}" }.toTypedArray()
            AlertDialog.Builder(this).setTitle("Pilih kalender tujuan")
                .setItems(labels) { _, which ->
                    selectedCalendar = calendars[which]
                    statusView?.text = "Kalender aktif: ${selectedCalendar?.name}\nAkun: ${selectedCalendar?.accountName}"
                    toast("Kalender dipilih: ${selectedCalendar?.name}")
                }.show()
        } catch (e: SecurityException) {
            toast("Izin kalender belum diberikan.")
        } catch (e: Exception) {
            toast("Gagal membaca kalender: ${e.message}")
        }
    }

    private fun importEvents() {
        if (!hasCalendarPermissions()) { checkCalendarPermissionAndOpen(); return }
        val cal = selectedCalendar
        if (cal == null) { chooseCalendar(); toast("Pilih kalender lalu tekan impor lagi."); return }
        try {
            val from = System.currentTimeMillis()
            val to = from + 30L * 24 * 60 * 60 * 1000
            val events = repo.readEvents(cal.id, from, to)
            val lines = events.take(80).map {
                val start = java.text.DateFormat.getDateTimeInstance().format(java.util.Date(it.startMillis))
                "$start — ${it.title}"
            }
            AlertDialog.Builder(this).setTitle("Acara kalender (${events.size})")
                .setMessage(if (lines.isEmpty()) "Tidak ada acara dalam 30 hari ke depan." else lines.joinToString("\n\n"))
                .setPositiveButton("Selesai", null).show()
            statusView?.text = "Impor berhasil dibaca: ${events.size} acara dari ${cal.name}. (Tampilan impor prototipe; belum disimpan sebagai model acara lokal.)"
        } catch (e: Exception) { toast("Gagal mengimpor: ${e.message}") }
    }

    private fun showCreateStudyEvent() {
        if (!hasCalendarPermissions()) { checkCalendarPermissionAndOpen(); return }
        val cal = selectedCalendar
        if (cal == null) { chooseCalendar(); toast("Pilih kalender lalu coba lagi."); return }
        val titleInput = EditText(this).apply { hint = "Judul acara"; setText("Belajar fokus — Ruang Fokus") }
        val descInput = EditText(this).apply { hint = "Catatan (opsional)"; setText("Sesi belajar dari Ruang Fokus") }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
            addView(titleInput); addView(descInput)
        }
        AlertDialog.Builder(this).setTitle("Tambah acara belajar")
            .setView(box)
            .setPositiveButton("Tambahkan") { _, _ ->
                try {
                    val start = LocalDate.now().atTime(13, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                    val end = start + 60 * 60 * 1000L
                    val id = repo.insertEvent(cal.id, titleInput.text.toString().ifBlank { "Belajar fokus" },
                        descInput.text.toString(), start, end, 10)
                    statusView?.text = "Acara ditambahkan. ID kalender: $id"
                    toast("Acara ditambahkan ke ${cal.name}.")
                } catch (e: Exception) { toast("Gagal menambah acara: ${e.message}") }
            }.setNegativeButton("Batal", null).show()
    }

    private fun showStudyAdvice() {
        val subjects = EditText(this).apply { hint = "Topik (contoh: Matematika)" }
        val minutes = EditText(this).apply { hint = "Waktu tersedia (menit)"; setText("45"); inputType = 2 }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
            addView(subjects); addView(minutes)
        }
        AlertDialog.Builder(this).setTitle("✨ Saran belajar")
            .setMessage("Saran lokal otomatis, belum tersambung ke model AI online.")
            .setView(box)
            .setPositiveButton("Buat saran") { _, _ ->
                val topic = subjects.text.toString().ifBlank { "materi pilihanmu" }
                val mins = minutes.text.toString().toIntOrNull()?.coerceIn(10, 180) ?: 45
                val focus = minOf(25, mins)
                AlertDialog.Builder(this).setTitle("Rencana $mins menit")
                    .setMessage("1. 5 menit: tulis apa yang sudah kamu tahu tentang $topic.\n\n2. $focus menit: fokus pada satu konsep atau latihan soal tanpa distraksi.\n\n3. 5 menit: tutup catatan dan jelaskan kembali dari ingatan.\n\n4. Sisa waktu: cek kesalahan dan tentukan langkah berikutnya.")
                    .setPositiveButton("OK", null).show()
            }.setNegativeButton("Batal", null).show()
    }

    private fun syncNow() {
        if (!hasCalendarPermissions()) { checkCalendarPermissionAndOpen(); return }
        if (selectedCalendar == null) { chooseCalendar(); return }
        // Safe MVP: read calendar changes on demand. A real two-way sync engine needs
        // persistent event mappings, change detection, conflict resolution and background work.
        importEvents()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
