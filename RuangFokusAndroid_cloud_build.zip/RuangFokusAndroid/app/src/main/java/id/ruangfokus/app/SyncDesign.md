# Desain yang diperlukan untuk sinkronisasi dua arah produksi

## Model data lokal yang disarankan (Room)
`PlannerItem(id, title, startMillis, endMillis, notes, category, updatedAt, deletedAt, source)`
`CalendarMapping(plannerItemId, calendarId, eventId, lastSeenFingerprint, lastSyncedAt)`
`SyncState(calendarId, lastSyncAt, lastError)`

## Aturan sinkronisasi
1. Saat pengguna memilih kalender, minta izin dan simpan hanya ID kalender yang dipilih.
2. Saat ekspor: jika mapping ada, update event tersebut; jika tidak ada, buat event dan simpan mapping.
3. Saat impor: baca acara pada rentang waktu yang relevan. Hanya impor acara yang diizinkan pengguna; hindari mengambil semua data kalender secara diam-diam.
4. Gunakan fingerprint yang dinormalisasi (judul, waktu, deskripsi) untuk mendeteksi perubahan.
5. Untuk perubahan dari kedua sisi sejak sinkron terakhir, tampilkan dialog konflik: “Pakai versi Ruang Fokus”, “Pakai versi Kalender”, atau “Tinjau manual”.
6. Penghapusan harus memakai tombstone dan konfirmasi; jangan menghapus acara kalender massal otomatis.
7. Gunakan `ContentObserver` untuk perubahan ketika proses aktif dan WorkManager untuk pekerjaan berkala. Keduanya bukan jaminan real-time.
8. Uji recurring events, timezone, all-day events, akun yang tidak bisa ditulis, kalender read-only, event yang dihapus dari akun cloud, dan provider OEM.
