# Roadmap Ruang Fokus — mahasiswa dengan uang saku terbatas

## Prioritas MVP berikutnya
1. **Uang saku:** saldo awal, catatan pemasukan/pengeluaran, kategori, ringkasan harian/mingguan, dan target tabungan; simpan lokal di perangkat.
2. **Menu hemat:** rencana menu 7 hari dengan anggaran sasaran maksimal Rp10.000/hari, daftar belanja, bahan pengganti, dan kolom edit harga. Semua harga adalah estimasi pengguna/lokal, bukan jaminan harga pasar.
3. **Planner:** tugas, tenggat, jadwal mingguan, kebiasaan, timer fokus, dan notifikasi yang bisa diatur.
4. **Saran pintar lokal:** rekomendasi berbasis jadwal, uang tersisa, dan preferensi yang disimpan di perangkat. Jangan menyebutnya AI online sampai model sungguhan diintegrasikan.
5. **Kalender:** impor/ekspor eksplisit terlebih dahulu; baru bangun sinkronisasi dua arah setelah database lokal, pemetaan event, penghapusan, konflik, pengulangan, dan pengujian selesai.

## Contoh anggaran makan (ilustrasi, bukan harga pasti)
- Karbohidrat: nasi/beras dari belanja rumah atau porsi warung.
- Protein murah: tempe, tahu, telur sesuai harga lokal.
- Sayur: pilih sayuran musiman yang sedang murah.
- Gunakan air minum isi ulang yang aman bila tersedia.

Rp10.000/hari bisa terlalu ketat untuk tiga kali makan lengkap di sebagian daerah. Aplikasi sebaiknya menampilkan estimasi, mengizinkan harga diedit, dan tidak mendorong mengurangi kebutuhan gizi. Jika ada makanan dari rumah/kantin subsidi, catat sumber itu agar anggaran realistis.
