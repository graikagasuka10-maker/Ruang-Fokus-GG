# Ruang Fokus Android — prototipe awal + alur build cloud

Aplikasi Android Kotlin untuk memulai Ruang Fokus. Proyek ini **belum merupakan aplikasi lengkap/produksi** dan belum diuji di perangkat Xiaomi/Redmi. Workflow GitHub Actions disertakan untuk membangun APK debug di cloud tanpa laptop.

## Fitur yang sudah ada di source
- Meminta izin baca/tulis kalender Android.
- Menampilkan daftar kalender yang diekspos Android Calendar Provider.
- Membaca dan menampilkan acara kalender 30 hari ke depan.
- Membuat acara belajar 1 jam dengan pengingat 10 menit, jika provider mendukung.
- Saran belajar lokal berbasis aturan sederhana (bukan AI online).
- Meminta izin notifikasi pada Android 13+.
- Workflow `.github/workflows/build-apk.yml` untuk membangun APK debug di GitHub Actions.

## Belum tersedia / belum diuji
- Menu keuangan lengkap, pencatatan pemasukan/pengeluaran persisten, target tabungan dan grafik.
- Generator menu makan hemat dengan harga lokal yang diperbarui.
- Planner lengkap dengan database lokal, edit/hapus tugas, kebiasaan, dan pengingat latar belakang yang andal.
- AI online (memerlukan layanan/model, koneksi internet, dan pengamanan kunci API).
- Sinkronisasi kalender dua arah otomatis. Tombol sinkronkan hanya membaca ulang acara; belum ada mapping acara lokal, deteksi perubahan/penghapusan, penanganan konflik, atau sinkronisasi latar belakang.
- Pengujian di MIUI/HyperOS dan perangkat nyata.
- APK release bertanda tangan untuk distribusi publik. Workflow menghasilkan APK debug untuk uji coba.

## Build APK lewat HP saja (GitHub Actions)
1. Di browser HP, buka https://github.com/ dan masuk/buat akun.
2. Buat repository baru bernama `RuangFokusAndroid`. Untuk repo privat, hasil build hanya terlihat oleh akunmu.
3. Ekstrak ZIP proyek ini di HP menggunakan aplikasi pengelola file yang mendukung ZIP.
4. Unggah isi folder proyek ke repository, termasuk folder tersembunyi `.github/workflows/build-apk.yml`. Pastikan file `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, folder `app/`, dan folder `.github/` ikut terunggah. Jangan unggah folder pembungkus ZIP tambahan.
5. Setelah file masuk ke branch `main`, buka tab **Actions** di repository. Pilih **Build Ruang Fokus APK** lalu **Run workflow** jika workflow belum berjalan otomatis.
6. Buka proses build terbaru yang berstatus berhasil. Di bagian **Artifacts**, unduh `ruang-fokus-debug-apk`.
7. Ekstrak ZIP artifact di HP, lalu ketuk `app-debug.apk` untuk memasang. Android mungkin meminta izin **Install unknown apps** untuk browser atau aplikasi File Manager yang digunakan. Aktifkan hanya untuk aplikasi yang dipercaya, lalu matikan lagi setelah instalasi jika mau.

Jika build gagal, buka log workflow dan periksa pesan error. Workflow ini adalah upaya build cloud, bukan jaminan APK berhasil sampai dependensi dan source berhasil dikompilasi.

## Catatan keamanan
APK debug hanya untuk uji coba pribadi. Jangan membagikan APK yang tidak kamu bangun sendiri atau tidak kamu percaya. Izin kalender memberi akses ke data acara pribadi. Jangan mengirim kalender ke layanan AI tanpa persetujuan jelas.
