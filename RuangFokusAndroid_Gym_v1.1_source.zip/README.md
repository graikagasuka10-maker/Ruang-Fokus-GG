# Ruang Fokus Android

Aplikasi Android native berbasis Kotlin dengan antarmuka minimalis sage green dan krem. Targetnya Android 8.0 (API 26) ke atas.

## Fitur yang tersedia di source

- **Beranda:** ringkasan tugas dan saldo berdasarkan catatan transaksi lokal.
- **Planner:** tambah tugas, tandai selesai, hapus tugas, dan simpan data secara lokal.
- **Kalender:** pilih kalender yang diekspos perangkat Android, baca acara 30 hari ke depan, dan tambahkan sesi belajar 1 jam dengan pengingat 10 menit (tergantung dukungan provider kalender).
- **Keuangan:** catat pemasukan/pengeluaran, kategori, saldo ringkas, riwayat, dan hapus transaksi. Tidak terhubung ke rekening bank.
- **Menu hemat:** anggaran mingguan, ide menu 7 hari, dan daftar belanja dengan status centang yang disimpan.
- **Belajar:** timer fokus 25 menit dan pembuat rencana belajar lokal berdasarkan topik serta durasi.
- **Gym:** program workout (full body pemula, upper body, lower body, recovery/mobilitas), pencatatan latihan per tanggal dengan set, repetisi, beban dan catatan, riwayat yang bisa dihapus, ringkasan jumlah catatan/hari latihan, serta estimasi volume total (set × repetisi × beban). Data gym disimpan lokal di perangkat. Program bersifat contoh umum dan perlu disesuaikan dengan kemampuan serta arahan pelatih bila tersedia.
- **Privasi:** tugas, transaksi, anggaran, status daftar belanja, dan catatan gym disimpan di SharedPreferences perangkat. Asisten belajar tidak memakai AI online dan tidak mengirim data ke server.

## Status build dan pengujian

Source versi pengembangan gym sudah diperbarui, tetapi **APK belum berhasil dibangun atau diuji dalam lingkungan penyusunan ini**. Lingkungan ini tidak memiliki Android SDK, `android.jar`, Gradle, atau Gradle wrapper, jadi jangan menganggap APK telah tersedia sampai workflow cloud selesai dengan status sukses. Kalender dan notifikasi juga perlu diuji pada perangkat Android nyata.

## Membuat APK debug melalui GitHub Actions (bisa dilakukan dari HP)

1. Buat repository GitHub baru, misalnya `RuangFokusAndroid`.
2. Unggah **isi folder** proyek ini ke branch `main`, termasuk folder tersembunyi `.github/workflows/`.
3. Buka tab **Actions**, pilih **Build Ruang Fokus APK**, lalu jalankan workflow bila belum berjalan otomatis.
4. Tunggu sampai proses build berstatus hijau/sukses.
5. Buka hasil workflow dan unduh artifact `ruang-fokus-debug-apk`. Ekstrak ZIP artifact lalu pasang `app-debug.apk` di perangkat Android.
6. Jika Android meminta izin memasang aplikasi dari sumber tersebut, pastikan artifact berasal dari repository milikmu yang tepercaya. Matikan kembali izin pemasangan setelah selesai bila diinginkan.

Workflow akan menjalankan `gradle assembleDebug` dan mengunggah APK hanya jika file APK benar-benar berhasil dibuat. APK debug ditujukan untuk uji coba pribadi, bukan distribusi publik. Untuk rilis publik, buat konfigurasi signing release yang aman.

## Izin

- `READ_CALENDAR` dan `WRITE_CALENDAR`: hanya digunakan jika pengguna memilih fitur kalender.
- `POST_NOTIFICATIONS`: diminta pada Android 13+; notifikasi timer lokal belum diimplementasikan sebagai notifikasi latar belakang.

## Batasan saat ini

- Kalender dibaca/ditulis secara langsung melalui Android Calendar Provider; belum ada sinkronisasi dua arah otomatis, konflik multi-perangkat, atau sinkronisasi latar belakang.
- Timer berjalan selama aplikasi masih aktif, tetapi bukan layanan timer latar belakang yang dijamin bertahan setelah aplikasi ditutup.
- Asisten belajar adalah pembuat saran lokal berbasis aturan, bukan model AI online.
- Harga menu tidak diperbarui dari pasar; anggaran dan menu perlu disesuaikan dengan harga setempat.
- UI dibuat dengan komponen Android native sederhana; perlu pengujian visual dan fungsional di perangkat nyata.
