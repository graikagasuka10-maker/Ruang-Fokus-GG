plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.ruangfokus.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.ruangfokus.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.1.0"
    }
}
