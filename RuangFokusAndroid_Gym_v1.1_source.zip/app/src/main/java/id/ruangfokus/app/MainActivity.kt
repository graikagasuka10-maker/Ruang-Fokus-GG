package id.ruangfokus.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val green = Color.rgb(74, 105, 87)
    private val sage = Color.rgb(222, 232, 219)
    private val cream = Color.rgb(250, 247, 239)
    private val ink = Color.rgb(42, 54, 46)
    private val muted = Color.rgb(112, 124, 113)
    private val prefs by lazy { getSharedPreferences("ruang_fokus_data", MODE_PRIVATE) }
    private lateinit var page: LinearLayout
    private lateinit var content: LinearLayout
    private var timer: CountDownTimer? = null
    private var timerRunning = false
    private var secondsLeft = 25 * 60
    private var selectedTab = "Beranda"
    private val money = NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = green
        window.navigationBarColor = cream
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        render("Beranda")
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 201)
        }
    }

    private fun render(tab: String) {
        selectedTab = tab
        page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cream) }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(page) }
        setContentView(scroll)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(22), dp(22), dp(20)); setBackgroundColor(green)
        }
        header.addView(label("RUANG FOKUS  ✦", 13f, Color.rgb(216, 232, 215), true))
        header.addView(label(tab, 28f, Color.WHITE, true).apply { setPadding(0, dp(7), 0, dp(3)) })
        header.addView(label(SimpleDateFormat("EEEE, d MMMM yyyy", Locale("id", "ID")).format(Date()), 13f, Color.rgb(231, 239, 227), false))
        page.addView(header)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundColor(Color.WHITE) }
        listOf("Beranda", "Planner", "Kalender", "Keuangan", "Menu hemat", "Belajar", "Gym").forEach { item ->
            val b = TextView(this).apply {
                text = item; textSize = 11f; gravity = Gravity.CENTER; setPadding(dp(7), dp(10), dp(7), dp(10))
                setTextColor(if (tab == item) Color.WHITE else green)
                setBackgroundColor(if (tab == item) green else Color.TRANSPARENT)
                setOnClickListener { render(item) }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        page.addView(nav)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(28)) }
        page.addView(content)
        when (tab) {
            "Beranda" -> home()
            "Planner" -> planner()
            "Kalender" -> calendarPage()
            "Keuangan" -> finance()
            "Menu hemat" -> meals()
            "Belajar" -> study()
            "Gym" -> gym()
        }
    }

    private fun home() {
        val tasks = readArray("tasks")
        val openTasks = (0 until tasks.length()).count { !tasks.optJSONObject(it).optBoolean("done") }
        val income = total("income"); val expense = total("expense")
        card {
            label("Halo, selamat datang kembali 🌿", 20f, ink, true)
            label("Ruang kecil untuk merapikan hari, belajar dengan tenang, dan menjaga anggaran.", 14f, muted)
            spacer(12)
            rowStats("Tugas tersisa", openTasks.toString(), "Saldo tercatat", money.format(income - expense))
        }
        section("Mulai dari sini")
        actionCard("✓  Planner harian", "Catat tugas dan tandai yang selesai") { render("Planner") }
        actionCard("◷  Timer fokus", "Sesi fokus dan saran belajar") { render("Belajar") }
        actionCard("↗  Keuangan pribadi", "Lihat pemasukan dan pengeluaran") { render("Keuangan") }
        actionCard("⌂  Menu hemat", "Susun menu dan daftar belanja") { render("Menu hemat") }
        actionCard("🏋  Gym tracker", "Rencana workout, catat set, repetisi, beban, dan progres") { render("Gym") }
        section("Pengingat kecil")
        card { label("Pilih satu tugas terpenting hari ini. Kerjakan 25 menit, lalu istirahat sebentar.", 15f, ink) }
    }

    private fun planner() {
        label("Simpan tugas di perangkat ini. Data tetap ada saat aplikasi ditutup.", 14f, muted)
        spacer(8)
        primary("＋ Tambah tugas") { taskDialog() }
        val tasks = readArray("tasks")
        if (tasks.length() == 0) emptyState("Belum ada tugas", "Tambahkan tugas pertama agar rencanamu mulai terbentuk.")
        for (i in 0 until tasks.length()) {
            val obj = tasks.optJSONObject(i) ?: continue
            card {
                val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val check = CheckBox(this@MainActivity).apply {
                    isChecked = obj.optBoolean("done"); buttonTintList = android.content.res.ColorStateList.valueOf(green)
                    setOnCheckedChangeListener { _, checked -> obj.put("done", checked); tasks.putAt(i, obj); saveArray("tasks", tasks); render("Planner") }
                }
                line.addView(check)
                val details = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                details.addView(label(obj.optString("title"), 16f, ink, true))
                details.addView(label(obj.optString("date", "Tanpa tanggal"), 12f, muted))
                line.addView(details, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                val del = TextView(this@MainActivity).apply { text = "Hapus"; textSize = 12f; setTextColor(green); setPadding(dp(8), dp(10), 0, dp(10)); setOnClickListener { tasks.remove(i); saveArray("tasks", tasks); render("Planner") } }
                line.addView(del); addView(line)
            }
        }
    }

    private fun taskDialog() {
        val title = EditText(this).apply { hint = "Nama tugas" }
        val date = EditText(this).apply { hint = "Tanggal (YYYY-MM-DD), opsional"; setText(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
        val box = formBox(title, date)
        AlertDialog.Builder(this).setTitle("Tugas baru").setView(box).setNegativeButton("Batal", null).setPositiveButton("Simpan") { _, _ ->
            if (title.text.toString().isNotBlank()) {
                val arr = readArray("tasks"); arr.put(JSONObject().put("title", title.text.toString().trim()).put("date", date.text.toString().trim()).put("done", false).put("created", System.currentTimeMillis()))
                saveArray("tasks", arr); render("Planner")
            } else toast("Nama tugas belum diisi.")
        }.show()
    }

    private fun calendarPage() {
        label("Kalender perangkat", 18f, ink, true)
        label("Akses kalender memerlukan izin Android. Acara akan dibuat di kalender yang kamu pilih.", 14f, muted)
        spacer(8)
        primary("Pilih kalender perangkat") { checkCalendarPermissionAndOpen() }
        primary("Baca acara 30 hari ke depan") { importEvents() }
        primary("Tambah jadwal belajar 1 jam") { showCreateStudyEvent() }
        primary("Saran belajar") { showStudyAdvice() }
        if (selectedCalendarName.isNotBlank()) label("Kalender aktif: $selectedCalendarName", 13f, green, true)
    }

    private var selectedCalendarName = ""
    private var calendars: List<DeviceCalendar> = emptyList()
    private var selectedCalendar: DeviceCalendar? = null
    private val repo by lazy { CalendarRepository(this) }
    private fun hasCalendarPermissions() = checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.WRITE_CALENDAR) == PackageManager.PERMISSION_GRANTED
    private fun checkCalendarPermissionAndOpen() {
        if (!hasCalendarPermissions()) requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR), 200) else chooseCalendar()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 200) { if (hasCalendarPermissions()) chooseCalendar() else toast("Izin kalender belum diberikan.") }
    }
    private fun chooseCalendar() {
        try {
            calendars = repo.listCalendars()
            if (calendars.isEmpty()) { toast("Tidak ada kalender yang tersedia di perangkat."); return }
            AlertDialog.Builder(this).setTitle("Pilih kalender").setItems(calendars.map { "${it.name} • ${it.accountName}" }.toTypedArray()) { _, which ->
                selectedCalendar = calendars[which]; selectedCalendarName = calendars[which].name; toast("Kalender dipilih: $selectedCalendarName"); render("Kalender")
            }.show()
        } catch (e: Exception) { toast("Gagal membuka kalender: ${e.message}") }
    }
    private fun importEvents() {
        if (!hasCalendarPermissions()) { checkCalendarPermissionAndOpen(); return }
        val cal = selectedCalendar ?: run { chooseCalendar(); return }
        try {
            val events = repo.readEvents(cal.id, System.currentTimeMillis(), System.currentTimeMillis() + 30L * 86400000)
            val lines = events.take(70).map { "${SimpleDateFormat("d MMM, HH:mm", Locale("id", "ID")).format(Date(it.startMillis))} — ${it.title}" }
            AlertDialog.Builder(this).setTitle("Acara kalender (${events.size})").setMessage(lines.ifEmpty { listOf("Belum ada acara 30 hari ke depan.") }.joinToString("\n\n")).setPositiveButton("Tutup", null).show()
        } catch (e: Exception) { toast("Gagal membaca kalender: ${e.message}") }
    }
    private fun showCreateStudyEvent() {
        if (!hasCalendarPermissions()) { checkCalendarPermissionAndOpen(); return }
        val cal = selectedCalendar ?: run { chooseCalendar(); return }
        val title = EditText(this).apply { setText("Belajar fokus — Ruang Fokus") }
        AlertDialog.Builder(this).setTitle("Jadwal belajar").setView(title).setNegativeButton("Batal", null).setPositiveButton("Tambahkan") { _, _ ->
            try {
                val startCal = Calendar.getInstance().apply { add(Calendar.MINUTE, 5); set(Calendar.SECOND, 0) }
                val start = startCal.timeInMillis; val end = start + 3600000L
                repo.insertEvent(cal.id, title.text.toString().ifBlank { "Belajar fokus" }, "Dibuat melalui Ruang Fokus", start, end, 10)
                toast("Jadwal ditambahkan ke kalender.")
            } catch (e: Exception) { toast("Gagal menambah acara: ${e.message}") }
        }.show()
    }
    private fun showStudyAdvice() {
        val topic = EditText(this).apply { hint = "Mata pelajaran / topik" }
        val mins = EditText(this).apply { hint = "Waktu tersedia (menit)"; setText("45"); inputType = 2 }
        AlertDialog.Builder(this).setTitle("Rencana belajar").setView(formBox(topic, mins)).setNegativeButton("Batal", null).setPositiveButton("Buat rencana") { _, _ ->
            val t = topic.text.toString().ifBlank { "materi pilihanmu" }; val m = (mins.text.toString().toIntOrNull() ?: 45).coerceIn(10, 180)
            AlertDialog.Builder(this).setTitle("Rencana $m menit").setMessage("• 5 menit: lihat kembali tujuan belajar $t.\n\n• ${minOf(25, m - 10)} menit: pelajari satu konsep dan kerjakan latihan.\n\n• 5 menit: tutup catatan lalu jelaskan dari ingatan.\n\n• Sisa waktu: periksa kesalahan dan catat pertanyaan.").setPositiveButton("Oke", null).show()
        }.show()
    }

    private fun finance() {
        val income = total("income"); val expense = total("expense")
        card { label("Saldo dari catatan", 13f, muted); label(money.format(income - expense), 28f, green, true); spacer(6); rowStats("Pemasukan", money.format(income), "Pengeluaran", money.format(expense)) }
        primary("＋ Catat pemasukan") { transactionDialog("income") }
        primary("－ Catat pengeluaran") { transactionDialog("expense") }
        section("Riwayat transaksi")
        val arr = readArray("transactions")
        if (arr.length() == 0) emptyState("Belum ada transaksi", "Catat transaksi untuk melihat ringkasan saldo.")
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.optJSONObject(i) ?: continue
            card {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val col = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL }
                col.addView(label(o.optString("title"), 15f, ink, true)); col.addView(label(o.optString("category"), 12f, muted))
                row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(label((if (o.optString("type") == "income") "+" else "−") + money.format(o.optLong("amount")), 14f, if (o.optString("type") == "income") green else Color.rgb(166, 91, 75), true))
                addView(row)
                val del = TextView(this@MainActivity).apply { text = "Hapus transaksi"; textSize = 12f; setTextColor(muted); setPadding(0, dp(8), 0, 0); setOnClickListener { arr.remove(i); saveArray("transactions", arr); render("Keuangan") } }; addView(del)
            }
        }
        label("Catatan disimpan lokal di perangkat, bukan rekening bank.", 12f, muted)
    }
    private fun transactionDialog(type: String) {
        val title = EditText(this).apply { hint = "Keterangan (mis. uang saku / makan)" }
        val amount = EditText(this).apply { hint = "Jumlah rupiah"; inputType = 2 }
        val category = EditText(this).apply { hint = "Kategori (mis. sekolah, makan)" }
        AlertDialog.Builder(this).setTitle(if (type == "income") "Pemasukan baru" else "Pengeluaran baru").setView(formBox(title, amount, category)).setNegativeButton("Batal", null).setPositiveButton("Simpan") { _, _ ->
            val value = amount.text.toString().toLongOrNull()
            if (title.text.isNotBlank() && value != null && value > 0) {
                val arr = readArray("transactions"); arr.put(JSONObject().put("title", title.text.toString().trim()).put("amount", value).put("category", category.text.toString().ifBlank { "Lainnya" }).put("type", type).put("time", System.currentTimeMillis()))
                saveArray("transactions", arr); render("Keuangan")
            } else toast("Isi keterangan dan jumlah rupiah yang valid.")
        }.show()
    }
    private fun total(type: String): Long { val a = readArray("transactions"); var sum = 0L; for (i in 0 until a.length()) { val o = a.optJSONObject(i) ?: continue; if (o.optString("type") == type) sum += o.optLong("amount") }; return sum }

    private fun meals() {
        val budgetInput = EditText(this).apply { hint = "Anggaran makan 7 hari (Rp)"; inputType = 2; setText(prefs.getString("meal_budget", "150000")) }
        card { label("Rencana menu 7 hari", 19f, ink, true); label("Menu sederhana yang bisa disesuaikan dengan bahan di rumah. Harga hanya perkiraan; sesuaikan dengan harga di daerahmu.", 13f, muted); spacer(8); addView(budgetInput) }
        primary("Simpan anggaran") { val b = budgetInput.text.toString().toLongOrNull(); if (b != null && b > 0) { prefs.edit().putString("meal_budget", b.toString()).apply(); render("Menu hemat") } else toast("Masukkan anggaran yang valid.") }
        val menus = listOf("Senin" to "Nasi, telur dadar, tumis kangkung", "Selasa" to "Nasi, tempe, sayur bening", "Rabu" to "Nasi, ayam suwir, mentimun", "Kamis" to "Nasi, tahu kecap, tumis sawi", "Jumat" to "Nasi, telur balado, sayur sop", "Sabtu" to "Bubur kacang hijau, pisang", "Minggu" to "Nasi goreng sayur dan telur")
        section("Menu minggu ini")
        menus.forEach { (day, menu) -> card { label(day, 13f, green, true); label(menu, 15f, ink) } }
        section("Daftar belanja")
        val groceries = listOf("Beras", "Telur", "Tempe dan tahu", "Sayuran hijau", "Wortel dan kentang", "Ayam (opsional)", "Pisang / buah musiman")
        groceries.forEach { item ->
            val key = "grocery_" + item.hashCode()
            val cb = CheckBox(this).apply { text = item; textSize = 14f; setTextColor(ink); isChecked = prefs.getBoolean(key, false); buttonTintList = android.content.res.ColorStateList.valueOf(green); setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(key, checked).apply() } }
            content.addView(cb)
        }
        label("Anggaran tersimpan: ${money.format(budgetInput.text.toString().toLongOrNull() ?: 150000)} untuk 7 hari.", 13f, muted)
    }

    private fun study() {
        card {
            label("Timer fokus", 20f, ink, true)
            label("Gunakan sesi singkat dan istirahat teratur.", 13f, muted)
            val clock = label(formatTime(secondsLeft), 42f, green, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(12)) }
            addView(clock)
            val controls = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            val start = Button(this@MainActivity).apply { text = "Mulai"; isAllCaps = false; setOnClickListener {
                if (!timerRunning) {
                    timerRunning = true; text = "Berjalan…"
                    timer = object : CountDownTimer(secondsLeft * 1000L, 1000) {
                        override fun onTick(millisUntilFinished: Long) { secondsLeft = (millisUntilFinished / 1000).toInt(); clock.text = formatTime(secondsLeft) }
                        override fun onFinish() { secondsLeft = 0; clock.text = "Selesai!"; timerRunning = false; start.text = "Mulai lagi"; toast("Sesi fokus selesai. Istirahat sejenak ya.") }
                    }.start()
                } else { timer?.cancel(); timerRunning = false; start.text = "Lanjutkan" }
            } }
            val reset = Button(this@MainActivity).apply { text = "Reset"; isAllCaps = false; setOnClickListener { timer?.cancel(); timerRunning = false; secondsLeft = 25 * 60; clock.text = formatTime(secondsLeft); start.text = "Mulai" } }
            controls.addView(start); controls.addView(reset); addView(controls)
        }
        section("Buat rencana belajar")
        val topic = EditText(this).apply { hint = "Topik yang ingin dipelajari" }
        val duration = EditText(this).apply { hint = "Durasi (menit)"; setText("45"); inputType = 2 }
        card { addView(topic); addView(duration); primary("Buat langkah belajar") {
            val t = topic.text.toString().ifBlank { "materi pilihanmu" }; val m = (duration.text.toString().toIntOrNull() ?: 45).coerceIn(10, 180)
            AlertDialog.Builder(this@MainActivity).setTitle("Rencana $m menit").setMessage("1. 5 menit — tetapkan tujuan untuk $t.\n\n2. ${minOf(25, m - 10)} menit — belajar aktif dan kerjakan latihan.\n\n3. 5 menit — ingat kembali tanpa melihat catatan.\n\n4. Sisa waktu — cek jawaban dan tulis hal yang belum dipahami.").setPositiveButton("Selesai", null).show()
        } }
        section("Catatan")
        label("Asisten belajar saat ini bekerja secara lokal dengan pola belajar sederhana. Belum memakai AI online atau mengirim data ke layanan luar.", 13f, muted)
    }


    private fun gym() {
        val logs = readArray("gym_logs")
        val sessions = (0 until logs.length()).mapNotNull { logs.optJSONObject(it) }
        val totalVolume = sessions.sumOf { it.optInt("sets") * it.optInt("reps") * it.optDouble("weight").toLong() }
        val uniqueDays = sessions.map { it.optString("date") }.distinct().size
        card {
            label("Ruang latihanmu", 20f, ink, true)
            label("Catat latihan dengan tenang, ikuti program, dan lihat perkembanganmu dari waktu ke waktu.", 14f, muted)
            spacer(10)
            rowStats("Catatan latihan", sessions.size.toString(), "Hari latihan", uniqueDays.toString())
            spacer(10)
            label("Total volume tercatat: ${String.format(Locale("id", "ID"), "%,d", totalVolume)} kg-repetisi", 13f, green, true)
        }
        primary("＋ Catat latihan") { gymLogDialog() }
        primary("▦ Lihat program workout") { workoutProgramDialog() }
        section("Ringkasan progres")
        if (sessions.isEmpty()) {
            emptyState("Belum ada catatan gym", "Simpan latihan pertama untuk mulai membangun riwayat progresmu.")
        } else {
            val exerciseNames = sessions.map { it.optString("exercise") }.distinct()
            card {
                label("Latihan terakhir", 15f, muted)
                label("${sessions.last().optString("exercise")} · ${sessions.last().optString("date")}", 17f, ink, true)
                spacer(8)
                label("Latihan yang pernah dicatat: ${exerciseNames.size}", 14f, ink)
                label("Jumlah sesi/catatan: ${sessions.size}", 14f, ink)
                label("Volume total: ${String.format(Locale("id", "ID"), "%,d", totalVolume)} kg-repetisi", 14f, ink)
            }
            section("Riwayat latihan")
            for (i in sessions.indices.reversed()) {
                val o = sessions[i]
                card {
                    label(o.optString("exercise"), 16f, ink, true)
                    label("${o.optString("date")} · ${o.optInt("sets")} set × ${o.optInt("reps")} repetisi · ${o.optDouble("weight")} kg", 13f, muted)
                    if (o.optString("notes").isNotBlank()) label(o.optString("notes"), 13f, ink)
                    val idx = i
                    val del = TextView(this@MainActivity).apply { text = "Hapus catatan"; textSize = 12f; setTextColor(Color.rgb(166, 91, 75)); setPadding(0, dp(8), 0, 0); setOnClickListener { logs.remove(idx); saveArray("gym_logs", logs); render("Gym") } }
                    addView(del)
                }
            }
        }
        label("Gunakan beban yang sesuai kemampuan, utamakan teknik yang benar, dan hentikan latihan jika terasa nyeri atau tidak nyaman.", 12f, muted).apply { setPadding(0, dp(8), 0, 0) }
    }

    private fun workoutProgramDialog() {
        val programs = listOf(
            "Full body pemula" to "Squat tanpa beban — 3 × 8–12\nPush-up (bisa versi lutut) — 3 × 6–10\nGlute bridge — 3 × 10–15\nRow dengan resistance band — 3 × 8–12\nPlank — 3 × 20–30 detik\n\nMulai ringan dan sisakan waktu istirahat antar set.",
            "Upper body" to "Chest press / push-up — 3 × 8–12\nLat pulldown / band row — 3 × 8–12\nShoulder press ringan — 2–3 × 8–12\nBiceps curl — 2 × 10–12\nTriceps extension — 2 × 10–12",
            "Lower body" to "Squat atau leg press — 3 × 8–12\nRomanian deadlift ringan — 3 × 8–10\nLunges — 2 × 8 tiap sisi\nHip thrust / glute bridge — 3 × 10–12\nCalf raise — 2 × 12–15",
            "Recovery / mobilitas" to "Jalan santai 10–20 menit\nGerakan mobilitas pinggul dan bahu\nPeregangan ringan tanpa memaksa\nIstirahat dan cukup tidur"
        )
        AlertDialog.Builder(this).setTitle("Pilih program workout")
            .setItems(programs.map { it.first }.toTypedArray()) { _, which ->
                AlertDialog.Builder(this).setTitle(programs[which].first).setMessage(programs[which].second)
                    .setPositiveButton("Selesai", null)
                    .setNeutralButton("Catat latihan") { _, _ -> gymLogDialog(programs[which].first) }
                    .show()
            }.setNegativeButton("Tutup", null).show()
    }

    private fun gymLogDialog(defaultExercise: String = "") {
        val exercises = arrayOf("Squat", "Leg press", "Bench press", "Push-up", "Lat pulldown", "Row", "Shoulder press", "Biceps curl", "Triceps extension", "Deadlift", "Hip thrust", "Plank", "Lainnya")
        val exercise = EditText(this).apply { hint = "Nama latihan (mis. squat)"; setText(defaultExercise.takeIf { it.isNotBlank() } ?: "") }
        val sets = EditText(this).apply { hint = "Jumlah set"; inputType = 2; setText("3") }
        val reps = EditText(this).apply { hint = "Repetisi per set"; inputType = 2; setText("10") }
        val weight = EditText(this).apply { hint = "Beban dalam kg (boleh 0 untuk bodyweight)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setText("0") }
        val date = EditText(this).apply { hint = "Tanggal (YYYY-MM-DD)"; setText(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())); isFocusable = false; setOnClickListener { val c = Calendar.getInstance(); DatePickerDialog(this@MainActivity, { _, y, m, d -> setText(String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)) }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show() } }
        val notes = EditText(this).apply { hint = "Catatan (opsional)" }
        AlertDialog.Builder(this).setTitle("Catat latihan")
            .setView(ScrollView(this).apply { addView(formBox(exercise, sets, reps, weight, date, notes)) })
            .setNegativeButton("Batal", null).setPositiveButton("Simpan") { _, _ ->
                val nSets = sets.text.toString().toIntOrNull()
                val nReps = reps.text.toString().toIntOrNull()
                val kg = weight.text.toString().toDoubleOrNull()
                if (exercise.text.isNotBlank() && nSets != null && nSets in 1..100 && nReps != null && nReps in 1..1000 && kg != null && kg >= 0 && date.text.isNotBlank()) {
                    val arr = readArray("gym_logs")
                    arr.put(JSONObject().put("exercise", exercise.text.toString().trim()).put("sets", nSets).put("reps", nReps).put("weight", kg).put("date", date.text.toString()).put("notes", notes.text.toString().trim()).put("created", System.currentTimeMillis()))
                    saveArray("gym_logs", arr); render("Gym"); toast("Catatan latihan tersimpan.")
                } else toast("Periksa nama latihan, set, repetisi, dan beban.")
            }.show()
    }

    private fun card(block: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15)); background = android.graphics.drawable.GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(18).toFloat(); setStroke(dp(1), Color.rgb(232, 233, 223)) }; elevation = dp(1).toFloat() }
        content.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }); box.block()
    }
    private fun actionCard(title: String, subtitle: String, action: () -> Unit) { card { label(title, 16f, ink, true); label(subtitle, 13f, muted); setOnClickListener { action() } } }
    private fun section(text: String) { label(text, 18f, ink, true).apply { setPadding(0, dp(12), 0, dp(10)) } }
    private fun label(text: String, size: Float, color: Int = ink, bold: Boolean = false): TextView = TextView(this).apply { this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD); setLineSpacing(dp(2).toFloat(), 1f) }
    private fun primary(text: String, action: () -> Unit) { val b = Button(this).apply { this.text = text; isAllCaps = false; setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(green); setOnClickListener { action() } }; content.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }) }
    private fun emptyState(title: String, desc: String) { card { label(title, 17f, ink, true); label(desc, 13f, muted) } }
    private fun rowStats(a: String, av: String, b: String, bv: String) { val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }; listOf(a to av, b to bv).forEach { (title, value) -> val c = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; addView(label(title, 12f, muted)); addView(label(value, 17f, green, true)) }; r.addView(c, LinearLayout.LayoutParams(0, -2, 1f)) }; addView(r) }
    private fun spacer(height: Int) { content.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }) }
    private fun formBox(vararg views: View) = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(8), dp(22), 0); views.forEach { addView(it) } }
    private fun readArray(key: String): JSONArray = try { JSONArray(prefs.getString(key, "[]")) } catch (_: Exception) { JSONArray() }
    private fun saveArray(key: String, array: JSONArray) { prefs.edit().putString(key, array.toString()).apply() }
    private fun JSONArray.putAt(index: Int, value: JSONObject) { val tmp = JSONArray(); for (i in 0 until length()) tmp.put(if (i == index) value else get(i)); for (i in length() - 1 downTo 0) remove(i); for (i in 0 until tmp.length()) put(tmp.get(i)) }
    private fun formatTime(s: Int) = String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    override fun onDestroy() { timer?.cancel(); super.onDestroy() }
}
